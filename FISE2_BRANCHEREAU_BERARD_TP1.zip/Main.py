'''
TP1 - Fractals
Nom élève : BERARD BRANCHEREAU
Groupe élève : FISE2_BRANCHEREAU_BERARD
File: main.py
Created Date: Wednesday December 1st 2021
Author: Ammar Mian
Contact: ammar.mian@univ-smb.fr
-----
Last Modified: Fri Jul 23 2021
Modified By: Marlene Berard et Elodie Branchereau
-----
Copyright (c) 2021 Université Savoie Mont-Blanc
'''

from math import sqrt
import matplotlib.pyplot as plt


class NombreComplexe:
    def __init__(self, real, imag):
        self.real = real
        self.imag = imag

    def __str__(self):
        chaine = ""
        if self.imag != 0:
            chaine = str(self.real) + " + " + str(self.imag) + "i"
        else:
            chaine = str(self.real)
        return chaine

    def module(self):
        return sqrt(self.real**2+self.imag**2)
    
    def __add__(self, i):
        return NombreComplexe(self.real + i.real, self.imag + i.imag)
    
    def __mul__(self,i):
        real = self.real * i.real - self.imag * i.imag
        imag = self.real * i.imag + self.imag * i.real
        return NombreComplexe(real , imag)
    
    def __pow__(self, n):
        puissance = NombreComplexe(1,0)
        for i in range(n):
                puissance = puissance * self
        return puissance
            

def nombre_complexe(k, l, n_y, n_x):
    """Renvoie un nombre complexe de la grille pour afficher l'ensemble de Mandelbrot.

    Parameters
    ----------
    k : int
        indice ligne.
    l : int
        indice colonne.
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.
    """
    zd = NombreComplexe(2, -1)
    pasx = 3/(n_x-1)
    pasy = -2/(n_y-1)
    
    return NombreComplexe(l*pasx-zd.real, k*pasy-zd.imag)


def grille_complexe(n_y, n_x):
    """Crée une grille de nombre complexes pour afficher l'ensemble de Mandelbrot.

    Parameters
    ----------
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.
    """
    grille = [] 
    for k in range(n_y):
        liste = []
        for l in range(n_x):
            liste.append(nombre_complexe(k, l, n_y, n_x))
        grille.append(liste)
    
    return grille


def est_divergente(c, N):
    """Vérifie si la suite de Mandelbrot diverge ou non à l'aide d'un nombre
    d'itérations en vérifiant si le module dépasse 2.

    Parameters
    ----------
    c : NombreComplexe
        le nombre complexe de décalage.
    N : int
        le nombre d'itérations maximum à partir du quel on considère 
        que la suite converge.
    """
    z = NombreComplexe(0, 0)
    for i in range(N):
        z = z**2 + c
        if z.module()>2:
            break
        
    return (z.module()>2)


def nombre_iterations(c, N):
    """Nombre d'itérations de la suite de Mandelbrot que l'on calcule
    tant que le module ne dépasse pas 2.

    Parameters
    ----------
    c : NombreComplexe
        le nombre complexe de décalage.
    N : int
        le nombre d'itérations maximum à partir du quel on considère 
        que la suite converge.

    Returns
    -------
    int
        nombre d'itérations faites.
    """
    pass


def image_mandelbrot(n_y, n_x, N):
    """Crée une image de Mandelbrot binaire de taille définie par les entrées et
    paramétrée par un nombre d'itérations maximum.

    Parameters
    ----------
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.
    N : int
        le nombre d'itérations maximum à partir du quel on considère 
        que la suite converge.
    """
    
    grille = grille_complexe(n_y, n_x)
    
    image = []
    for k in range(n_y):
        liste_image = []
        for l in range(n_x):
            if est_divergente(grille[k][l], N) == True:
                liste_image.append(255)
            else :
                liste_image.append(0)
        image.append(liste_image)
    return image
            


def image_mandelbrot_couleur(n_y, n_x, N):
    """Crée une image de Mandelbrot en couleur de taille définie par les entrées et
    paramétrée par un nombre d'itérations maximum.

    Parameters
    ----------
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.
    N : int
        le nombre d'itérations maximum à partir du quel on considère 
        que la suite converge.

    Returns
    -------
    list
        l'image sous forme de liste de liste.
    """
    pass


def nombre_complexe_numpy(k, l, n_y, n_x):
    """Renvoie un nombre complexe de la grille pour afficher l'ensemble de Mandelbrot.

    Parameters
    ----------
    k : int
        indice ligne.
    l : int
        indice colonne.
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.

    Returns
    -------
    NombreComplexe
        le nombre complexe correspondant.
    """
    pass


def grille_complexe_numpy(n_y, n_x):
    """Crée une grille de nombre complexes pour afficher l'ensemble de Mandelbrot.
    Version à l'aide de numpy.

    Parameters
    ----------
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.

    Returns
    -------
    array, de taille (n_y, n_x)
        la grille sous forme d'un array numpy.
    """
    pass


def image_mandelbrot_numpy_couleur(n_y, n_x, N):
    """Crée une image de Mandelbrot couleur de taille définie par les entrées et
    paramétrée par un nombre d'itérations maximum. Version avec numpy.

    Parameters
    ----------
    n_y : int
        nombre de points en ligne.
    n_x : int
        nombre de points en colonne.
    N : int
        le nombre d'itérations maximum à partir du quel on considère 
        que la suite converge.

    Returns
    -------
    array, de taille (n_y, n_x)
        la grille sous forme d'un array numpy.
    """
    c = grille_complexe_numpy(n_y, n_x)
    z = np.zeros((n_y, n_x), dtype=complex)
    masque_non_divergent = np.full((n_y, n_x), True, dtype=bool)
    image = np.zeros((n_y, n_x))
    for n in trange(N):
        z[masque_non_divergent] = z[masque_non_divergent]**2 +\
                                  c[masque_non_divergent]
        masque_nouveau_divergent = np.logical_and(
            masque_non_divergent, np.abs(z) > 2
        )
        image[masque_nouveau_divergent] = n
        masque_non_divergent = (np.abs(z) <= 2)
    return image


if __name__ == '__main__':
    i1 = NombreComplexe(1, 10)
    i2 = NombreComplexe(5, -10)
    i3 = NombreComplexe(-3, 0)
    
    #affiche le module de i1
    print(i1.module(),'\n')
    
    #affiche les nombres complexes 
    print(i1)
    print(i2)
    print(i3,'\n')
    
    #surchage des fonctions
    print(i1+i2)  
    print(i3*i1)
    print(i1*i1)
    print(i1**2,'\n')
     
    #affichage de grille
    n_x = 100
    n_y = 200
    N = 20
    
    grille = grille_complexe(n_y, n_x)
    afficheGrille = [] 
    for k in range(n_y):
        afficheListe = []
        for l in range(n_x):
            afficheListe.append(str(grille[k][l]))
        afficheGrille.append(afficheListe)
    print(afficheGrille)
    
    print('\n')
    
    #variable tableau module
    tableau_module = []
    for k in range(n_y):
        liste_tableau = []
        for l in range(n_x):
            liste_tableau.append(grille[k][l].module())
        tableau_module.append(liste_tableau)
    print(tableau_module)
    
    #affiche tableau en point
    #plt.figure()
    #plt.imshow(tableau_module, aspect = 'auto')
    #plt.colorbar()
    #plt.show()
    
    #affiche image mandelbrot
    plt.figure()
    plt.imshow(image_mandelbrot(n_y, n_x, N), aspect = 'auto')
    plt.colorbar()
    plt.show()
    
    
    